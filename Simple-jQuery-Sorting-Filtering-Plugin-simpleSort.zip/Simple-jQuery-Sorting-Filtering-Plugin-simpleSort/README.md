# simpleSort 
Very simple Javascript/jQuery script for sorting &amp; filtering elements inside a parent container

[Demo](http://amadreason.github.io/simpleSort/)
